package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import svc.SpecialtiesQuickService;
import vo.ActionForward;

public class SpecialtiesQuickAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {


		SpecialtiesQuickService specialtiesQuickService = new SpecialtiesQuickService();
		
		return null;
	}

}
