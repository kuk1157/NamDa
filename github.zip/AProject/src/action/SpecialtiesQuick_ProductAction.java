package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import svc.SpecialtiesQuick_ProductService;
import vo.ActionForward;

public class SpecialtiesQuick_ProductAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		SpecialtiesQuick_ProductService specialtiesQuick_ProductAction = new SpecialtiesQuick_ProductService();
		
		return null;
	}

}
