package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import svc.SpecialtiesCartRemoveService;
import vo.ActionForward;

public class SpecialtiesCartRemoveAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String [] kindArray = request.getParameterValues("remove");
		SpecialtiesCartRemoveService specialtiesCartRemoveService =  new SpecialtiesCartRemoveService();
		specialtiesCartRemoveService.cartRemove(request, kindArray);
		ActionForward forward = new ActionForward("specialtiesCartList.Specialties", true);
		
	return forward;
	}
}
