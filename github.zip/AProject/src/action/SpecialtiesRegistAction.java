package action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import svc.SpecialtiesRegistService;
import vo.ActionForward;

import vo.Specialties;

public class SpecialtiesRegistAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		
		SpecialtiesRegistService specialtiesRegistService =new SpecialtiesRegistService();
		String realFolder = "";
		
		String saveFolder = "/images";
		String encType = "utf-8";
		int maxSize = 5*1024*1024;
		
		ServletContext context = request.getServletContext();
		realFolder =context.getRealPath(saveFolder);
		MultipartRequest multi = new MultipartRequest(request, realFolder, maxSize, encType, new DefaultFileRenamePolicy());
		String image = multi.getFilesystemName("image");
		
		Specialties specialties = new Specialties(multi.getParameter("product_code"),multi.getParameter("title"),Integer.parseInt(multi.getParameter("price")),multi.getParameter("content"),image,multi.getParameter("status")); 
		
			
			 /* String product_code = multi.getParameter("product_code"); 
			  String tilte =multi.getParameter("title"); 
			  String status = multi.getParameter("status");
			  String content = multi.getParameter("content"); 
			  int price = Integer.parseInt(multi.getParameter("price"));*/
			  
			 
			 
		
		
	
		 /* specialties.setProduct_code(request.getParameter("product_code"));
		  specialties.setImage(request.getParameter("image"));
		  specialties.setTitle(request.getParameter("title"));
		  specialties.setStatus(request.getParameter("status"));
		  specialties.setContent(request.getParameter("content"));
		  specialties.setPrice(Integer.parseInt(request.getParameter("price"))); */
		 
		boolean isRegistSuccess = SpecialtiesRegistService.registSpecialties(specialties);
		ActionForward forward = null;
		
		
		
		if(isRegistSuccess) {
			forward = new ActionForward("specialtiesList.Specialties", true);
			
		}else {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('등록실패');");
			out.println("history.back();");
			out.println("</script>");
			
		}
		
		return forward;
	}

}