package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import svc.SpecialtiesCartQtyDownService;
import vo.ActionForward;

public class SpecialtiesCartQtyDownAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		int qty = Integer.parseInt(request.getParameter("qty"));
		SpecialtiesCartQtyDownService specialtiesCartQtyDownService = new SpecialtiesCartQtyDownService();
		specialtiesCartQtyDownService.downCartQty(qty, request);
		ActionForward forward = new ActionForward("specialtiesCartList.Specialties", true);
		
		return forward;
	
	}
}
