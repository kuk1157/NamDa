package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import svc.SpecialtiesCartQtyUpService;
import vo.ActionForward;

public class SpecialtiesCartQtyUpAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {

		int qty = Integer.parseInt(request.getParameter("qty"));
		SpecialtiesCartQtyUpService specialtiesCartQtyUpService = new SpecialtiesCartQtyUpService();
		specialtiesCartQtyUpService.downCartQty(qty, request);
		ActionForward forward = new ActionForward("specialtiesCartList.Specialties", true);
		
		return forward;
	
	}
}
