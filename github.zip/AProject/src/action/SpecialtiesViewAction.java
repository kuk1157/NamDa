package action;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import svc.SpecialtiesViewService;
import vo.ActionForward;

import vo.Specialties;

public class SpecialtiesViewAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		SpecialtiesViewService specialtiesViewService = new SpecialtiesViewService();
		String product_code = request.getParameter("product_code");
		Specialties specialties = specialtiesViewService.getSpecialtiesView(product_code);
		request.setAttribute("specialties", specialties);
		Cookie todayImageCookie = new Cookie("today"+product_code, specialties.getImage());
		todayImageCookie.setMaxAge(60*60*24);
		response.addCookie(todayImageCookie);
		ActionForward forward = new ActionForward("specialtiesView.jsp", false);
		
		
		return forward;
	
	}

}
