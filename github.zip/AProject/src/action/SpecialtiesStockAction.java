package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import svc.SpecialtiesStockService;
import vo.ActionForward;

public class SpecialtiesStockAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		SpecialtiesStockService specialtiesStockService = new SpecialtiesStockService();
		return null;
	}

}
