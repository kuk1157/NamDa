package action;

import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import svc.SpecialtiesCartAddService;
import vo.ActionForward;
import vo.Cart;


public class SpecialtiesCartAddAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		
		/*
		 * String realFolder = "";
		 * 
		 * String saveFolder = "/images"; String encType = "utf-8"; int maxSize =
		 * 5*1024*1024;
		 * 
		 * ServletContext context = request.getServletContext(); realFolder
		 * =context.getRealPath(saveFolder); MultipartRequest multi = new
		 * MultipartRequest(request, realFolder, maxSize, encType, new
		 * DefaultFileRenamePolicy());
		 * 
		 * Cart cart = new
		 * Cart(Integer.parseInt(multi.getParameter("index_num")),multi.getParameter(
		 * "id"),Integer.parseInt(multi.getParameter("qty")),multi.getParameter(
		 * "product_code"),Integer.parseInt(multi.getParameter("price")));
		 */
		
		Cart cart = new Cart();
		
		cart.setIndex_num(Integer.parseInt(request.getParameter("index_num")));
		cart.setId(request.getParameter("id"));
		cart.setQty(Integer.parseInt(request.getParameter("qty")));
		cart.setProduct_code(request.getParameter("product_code"));
		cart.setPrice(Integer.parseInt(request.getParameter("price")));
		
		SpecialtiesCartAddService specialtiesCartAddService = new SpecialtiesCartAddService(); 
		boolean isCartSuccess = specialtiesCartAddService.addCart(cart);
		
		if(isCartSuccess) {
			forward = new ActionForward();
			forward.setPath("specialtiesList.Specialties");
			forward.setRedirect(true);
		}else {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('장바구니등록실패');");
			out.println("history.back();");
			out.println("</script>");
		}
		/*
		  String product_code = request.getParameter("product_code"); Specialties
		  cartSpecialties = specialtiesCartAddService.getCartSpecialties(product_code);
		  specialtiesCartAddService.addCart(request, cartSpecialties);
		 */
		
		/*
		 ActionForward forward = new ActionForward("specialtiesCartList.Specialties",
		  true);
		 */
		
		return forward;
	}

}
