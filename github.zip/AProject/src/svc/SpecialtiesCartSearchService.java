package svc;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import vo.Cart;

public class SpecialtiesCartSearchService {

	public ArrayList<Cart> getCartSearchList(int startMoney, int endMoney, HttpServletRequest request) {
		// TODO Auto-generated method stub
		return null;
	}

}
