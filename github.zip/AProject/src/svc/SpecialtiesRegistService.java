package svc;

import static db.JdbcUtil.close;
import static db.JdbcUtil.commit;
import static db.JdbcUtil.getConnection;
import static db.JdbcUtil.rollback;

import java.sql.Connection;

import dao.SpecialtiesDAO;
import vo.Specialties;

public class SpecialtiesRegistService {

public static boolean registSpecialties(Specialties specialties)  {
		
		
	SpecialtiesDAO specialtiesDAO = SpecialtiesDAO.getInstance();
		Connection con = getConnection();
		specialtiesDAO.setConnection(con);
		boolean isRegistSuccess = false;
		int insertCount =specialtiesDAO.insertSpecialties(specialties);
		
		if(insertCount>0) {
			commit(con);
			isRegistSuccess=true;
		}else {
			rollback(con);
		}
		close(con);
		return isRegistSuccess;
	}
}

