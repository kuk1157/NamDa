package svc;

import static db.JdbcUtil.close;
import static db.JdbcUtil.commit;
import static db.JdbcUtil.getConnection;
import static db.JdbcUtil.rollback;

import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;

import dao.CartDAO;
import vo.Cart;
import vo.Specialties;

public class SpecialtiesCartAddService {

	public boolean addCart(Cart cart) {
		boolean isCartSuccess = false;
		
		Connection con = null;
		try {
			con = getConnection();
			CartDAO cartDAO = CartDAO.getInstance();
			cartDAO.setConnection(con);
			
			int insertCount = cartDAO.insertCart(cart);
			
			if(insertCount > 0) {
				commit(con);
				isCartSuccess = true;
			}else {
				rollback(con);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			close(con);
		}
		return isCartSuccess;
	}

}
