package svc;

public class SpecialtiesQuickService {

}
