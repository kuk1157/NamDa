package svc;

public class SpecialtiesStockService {

}
