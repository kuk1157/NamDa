package svc;

import static db.JdbcUtil.close;
import static db.JdbcUtil.getConnection;

import java.sql.Connection;
import java.util.ArrayList;


import dao.SpecialtiesDAO;
import vo.Specialties;

public class SpecialtiesListService {

	public ArrayList<Specialties> getSpecialtiesList() {
		SpecialtiesDAO specialtiesDAO = SpecialtiesDAO.getInstance();
		Connection con = getConnection();
		specialtiesDAO.setConnection(con);
		ArrayList<Specialties> specialtiesList = specialtiesDAO.selectSpecialtiesList();
		close(con);
		return specialtiesList;
	}

}
