package svc;

import javax.servlet.http.HttpServletRequest;

public class SpecialtiesCartRemoveService {

	public void cartRemove(HttpServletRequest request, String[] kindArray) {
		// TODO Auto-generated method stub
		
	}

}
