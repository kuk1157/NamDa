package svc;

import javax.servlet.http.HttpServletRequest;

public class SpecialtiesCartQtyDownService {

	public void downCartQty(int qty, HttpServletRequest request) {
		// TODO Auto-generated method stub
		
	}

}
