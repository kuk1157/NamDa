package svc;

import static db.JdbcUtil.close;
import static db.JdbcUtil.commit;
import static db.JdbcUtil.getConnection;
import static db.JdbcUtil.rollback;

import java.sql.Connection;


import dao.SpecialtiesDAO;

import vo.Specialties;

public class SpecialtiesViewService {

	public Specialties getSpecialtiesView(String product_code) {
			SpecialtiesDAO specialtiesDAO = SpecialtiesDAO.getInstance();
			Connection con = getConnection();
			specialtiesDAO.setConnection(con);
			
			int updateCount =specialtiesDAO.updateReadCount(product_code);
			
			if(updateCount>0) {
				commit(con);
			
			}else {
				rollback(con);
			}
			
			Specialties specialties = SpecialtiesDAO.selectSpecialties(product_code);
			close(con);
			return specialties;
		}

}
