package svc;

import static db.JdbcUtil.*;
import java.sql.Connection;

import dao.LoginDAO;
import vo.MemberBean;

public class LoginService {

	public MemberBean getLoginMember(String id, String passwd) {
		
//		Member loginMember = null;
//		LoginDAO loginDAO = LoginDAO.getInstance();
//		Connection con = null;
//		try {
//		con=getConnection();
//				loginDAO.setConnection(con);
//			loginMember=LoginDAO.selectLoginMember(String id,String passwd);
//		}catch(Exception e) {
//			e.printStackTrace();
//		}finally {
//			close(con);
//		}
	LoginDAO loginDAO = LoginDAO.getInstance();
	Connection con = getConnection();
	loginDAO.setConnection(con);
	MemberBean loginMember = loginDAO.selectLoginMember(id,passwd);
	close(con);
		return loginMember;
	}

}
