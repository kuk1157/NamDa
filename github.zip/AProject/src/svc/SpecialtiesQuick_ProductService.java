package svc;

public class SpecialtiesQuick_ProductService {

}
