package svc;

import javax.servlet.http.HttpServletRequest;

public class SpecialtiesCartQtyUpService {

	public void downCartQty(int qty, HttpServletRequest request) {
		// TODO Auto-generated method stub
		
	}

}
