package svc;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import vo.Cart;

public class SpecialtiesCartListService {

	public ArrayList<Cart> getCartList(HttpServletRequest request) {
		// TODO Auto-generated method stub
		return null;
	}

}
