package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import action.Action;

import action.JoinProAction;
import action.SpecialtiesCartAddAction;
import action.SpecialtiesCartListAction;
import action.SpecialtiesCartQtyDownAction;
import action.SpecialtiesCartQtyUpAction;
import action.SpecialtiesCartRemoveAction;
import action.SpecialtiesCartSearchAction;
import action.SpecialtiesListAction;
import action.SpecialtiesQuickAction;
import action.SpecialtiesQuick_ProductAction;
import action.SpecialtiesRegistAction;
import action.SpecialtiesRegistFormAction;
import action.SpecialtiesStockAction;
import action.SpecialtiesViewAction;
import vo.ActionForward;

/**
 * Servlet implementation class MemberFrontController
 */
@WebServlet(urlPatterns = { "*.mem", "*.Specialties", "*.log" })
public class SpecialtiesFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SpecialtiesFrontController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doProcess(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doProcess(request, response);
	}

	private void doProcess(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		request.setCharacterEncoding("utf-8");
		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = requestURI.substring(contextPath.length());
		System.out.println(command);
		ActionForward forward = null;
		Action action = null;

		if (command.equals("/loginForm.log")) {
			forward = new ActionForward();
			forward.setPath("loginForm.html");
		} else if (command.equals("/joinForm.mem")) {
			forward = new ActionForward();
			forward.setPath("/member/joinForm.jsp");
		} else if (command.equals("/joinProcess.mem")) {
			action = new JoinProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (command.equals("/specialtiesRegist.Specialties")) {
			action = new SpecialtiesRegistAction();

			try {
				forward = action.execute(request, response);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		else if (command.equals("/specialtiesRegistForm.Specialties")) {
			action = new SpecialtiesRegistFormAction();

			try {
				forward = action.execute(request, response);

			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		

		/*
		 * else if(command.equals("/specialtiesList.Specialties")) action = new
		 * specialtiesListAction();
		 */

		else if (command.equals("/specialtiesQuick.Specialties")) {
			action = new SpecialtiesQuickAction();

			try {
				forward = action.execute(request, response);

			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		else if (command.equals("/specialtiesQuick_Product.Specialties")) {
			action = new SpecialtiesQuick_ProductAction();

			try {
				forward = action.execute(request, response);

			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		else if (command.equals("/specialtiesQuick_Product.Specialties")) {
			action = new SpecialtiesQuick_ProductAction();

			try {
				forward = action.execute(request, response);

			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		else if (command.equals("/specialtiesStock.Specialties")) {
			action = new SpecialtiesStockAction();

			try {
				forward = action.execute(request, response);

			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		else if(command.equals("/specialtiesList.Specialties")) {
			action = new SpecialtiesListAction();
			
		try {
			forward = action.execute(request, response);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
		else if(command.equals("/specialtiesView.Specialties")) {
			action = new SpecialtiesViewAction();
		
		try {
			forward = action.execute(request, response);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
		
		else if(command.equals("/specialtiesCartAdd.Specialties")) {
			action = new SpecialtiesCartAddAction();
		
		try {
			forward = action.execute(request, response);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
		
		else if(command.equals("/specialtiesCartList.Specialties")) {
			action = new SpecialtiesCartListAction();
		
		try {
			forward = action.execute(request, response);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
		
		else if(command.equals("/specialtiesCartSearch.Specialties")) {
			action = new SpecialtiesCartSearchAction();
		
		try {
			forward = action.execute(request, response);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
		
		else if(command.equals("/specialtiesCartRemove.Specialties")) {
			action = new SpecialtiesCartRemoveAction();
		
		try {
			forward = action.execute(request, response);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
		
		else if(command.equals("/specialtiesCartQtyUp.Specialties")) {
			action = new SpecialtiesCartQtyUpAction();
		
		try {
			forward = action.execute(request, response);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
		
		else if(command.equals("/specialtiesCartQtyDown.Specialties")) {
			action = new SpecialtiesCartQtyDownAction();
		
		try {
			forward = action.execute(request, response);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
		
		/*
		 * } else if(command.equals("/loginProcess.log")) { action = new
		 * LoginProAction(); try { forward = action.execute(request, response);
		 * }catch(Exception e) { e.printStackTrace(); } } else
		 * if(command.equals("/logout.log")) { HttpSession session =
		 * request.getSession(); session.invalidate(); //session.removeAttribute("id");
		 * forward = new ActionForward(); forward.setRedirect(true);
		 * forward.setPath("loginmain.jsp"); } else
		 * if(command.equals("/member_list.mem")) { action = new MemberListProAction();
		 * try { forward = action.execute(request, response); }catch(Exception e) {
		 * e.printStackTrace(); } }else if(command.equals("/memberInfo.mem")) { action =
		 * new MemberInfoProAction(); try { forward = action.execute(request, response);
		 * }catch(Exception e) { e.printStackTrace(); } }else
		 * if(command.equals("/memberModForm.mem")) { action = new
		 * MemberModFormAction(); try { forward = action.execute(request, response);
		 * }catch(Exception e) { e.printStackTrace(); } }else
		 * if(command.equals("/memberModPro.mem")) { action = new MemberModProAction();
		 * try { forward = action.execute(request, response); }catch(Exception e) {
		 * e.printStackTrace(); } }else if(command.equals("/memberDel.mem")) { action =
		 * new MemberDelAction(); try { forward = action.execute(request, response);
		 * }catch(Exception e) { e.printStackTrace(); } }
		 */
		if (forward != null) {
			if (forward.isRedirect()) {
				response.sendRedirect(forward.getPath());
			} else {
				RequestDispatcher dispatcher = request.getRequestDispatcher(forward.getPath());
				dispatcher.forward(request, response);

			}

		}

	}
}