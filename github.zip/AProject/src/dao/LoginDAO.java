
package dao;

import static db.JdbcUtil.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import vo.MemberBean;

public class LoginDAO {

	private static LoginDAO loginDAO;
	private Connection con;
	
	public LoginDAO() {
		
	}
	
	public static LoginDAO getInstance() {
		if(loginDAO == null) {
			loginDAO = new LoginDAO();
		}
		return loginDAO;
	}

	public void setConnection(Connection con) {
		// TODO Auto-generated method stub
		this.con=con;
	}

	public MemberBean selectLoginMember(String id, String pass) {
		// TODO Auto-generated method stub
		MemberBean loginMember = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement("select * from member where id =? and pass=?");
			pstmt.setString(1, id);
			pstmt.setString(2, pass);
			rs= pstmt.executeQuery();
			if(rs.next()) {
				loginMember = new MemberBean();
				loginMember.setId(rs.getString("id"));
				loginMember.setName(rs.getString("name"));
				loginMember.setPass(rs.getString("pass"));
				loginMember.setPhone_number(rs.getString("phone_number"));
				loginMember.setEmail(rs.getString("email"));
				loginMember.setBirthday(rs.getString("birthday"));
	
			}
			}catch(Exception e) {
				e.printStackTrace();
			}finally {
				try {
					close(rs);
					close(pstmt);
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
			return loginMember;
	}

}
