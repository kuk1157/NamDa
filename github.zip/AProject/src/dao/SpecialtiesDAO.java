package dao;


import static db.JdbcUtil.*;
import java.sql.*;
import java.util.ArrayList;
import vo.Specialties;

public class SpecialtiesDAO {

	
	/* static Connection con; */
	
	static Connection con;
	private static SpecialtiesDAO productDAO;
	
	private SpecialtiesDAO() {
		
	}
	
	public void setConnection(Connection con) {
		this.con = con;
		
	}
	
	public static SpecialtiesDAO getInstance() {
		if(productDAO == null) {
			productDAO = new SpecialtiesDAO();
		}
		return productDAO;
	}

	public ArrayList<Specialties> selectSpecialtiesList() {
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<Specialties> specialtiesList = null;
		
		try {
			pstmt = con.prepareStatement("select * from product");
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				specialtiesList = new ArrayList<Specialties>();
				
				do {
					specialtiesList.add(new Specialties(
							rs.getString("product_code"),
							rs.getString("title"),
							rs.getInt("price"),
							rs.getString("content"),
							rs.getString("image"),
							rs.getString("status")));	
				}while(rs.next());
				   
				}
			}catch(SQLException e){
				e.printStackTrace();
				
		}finally {
			close(rs);
			close(pstmt);
		}
		
		return specialtiesList;
	}
	
	/* public static Specialties selectSpecialties(String product_code) { */
		
	
	public static Specialties selectSpecialties(String product_code) {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Specialties specialties = null;
		
		try {
			pstmt = con.prepareStatement("select * from product where product_code=?");
			pstmt.setString(1, product_code);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				specialties = new Specialties(
						rs.getString("product_code"),
						rs.getString("title"),
						rs.getInt("price"),
						rs.getString("content"),
						rs.getString("image"),
						rs.getString("status"));			
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
			close(rs);
		}
	
		return specialties;
	}
	
	public int updateReadCount(String product_code) {
		PreparedStatement pstmt = null;
		int updateCount = 0;
		String sql ="";
		
		try {
			sql = "update Product set readcount = readcount + 1 where product_code = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, product_code);
			updateCount = pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		
		return updateCount;
	}
	

	public int insertSpecialties(Specialties specialties) {
		PreparedStatement pstmt = null;
		int insertCount = 0;
		/* String sql =""; */
		
		System.out.println(specialties.toString());
		try {
			String sql = "insert into product values (?,?,?,?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, specialties.getProduct_code());
			pstmt.setString(2, specialties.getTitle());
			pstmt.setInt(3, specialties.getPrice());
			pstmt.setString(4, specialties.getContent());
			pstmt.setString(5, specialties.getImage());
			pstmt.setString(6, specialties.getStatus());
			insertCount = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
			
		}
		
		return insertCount;
	}

}