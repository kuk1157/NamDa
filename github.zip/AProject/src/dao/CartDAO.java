package dao;

import static db.JdbcUtil.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import vo.Cart;
import vo.MemberBean;


public class CartDAO {
	

		private static CartDAO cartDAO;
		private Connection con;
		
		public CartDAO() {
			
		}
		
		public static CartDAO getInstance() {
			if(cartDAO == null) {
				cartDAO = new CartDAO();
			}
			return cartDAO;
		}

		public void setConnection(Connection con) {
			// TODO Auto-generated method stub
			this.con=con;
		}

		public int insertCart(Cart cart) {
			int insertCount = 0;
			PreparedStatement pstmt = null;
			String sql = "insert into cart values (?,?,?,?,?)";
			
			try {
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, cart.getIndex_num());
				pstmt.setString(2, cart.getId());
				pstmt.setInt(3, cart.getQty());
				pstmt.setString(4, cart.getProduct_code());
				pstmt.setInt(5, cart.getPrice());
				
				insertCount = pstmt.executeUpdate();
			}catch(Exception e) {
				e.printStackTrace();
			}finally {
				close(pstmt);
			}
			return insertCount;
		}

		public Cart selectCart(String product_code) {
			Cart cart = null;
			
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = "select * from cart where product_code=?";
			try {
				pstmt = con.prepareStatement(sql);
				pstmt.setString(4, product_code);
				rs = pstmt.executeQuery();
				if(rs.next()) {
					cart = new Cart();
					cart.setIndex_num(rs.getInt("index_num"));
					cart.setId(rs.getString("id"));
					cart.setQty(rs.getInt("qty"));
					cart.setProduct_code(rs.getString("product_code"));
					cart.setPrice(rs.getInt("price"));
					
				}
			}catch(Exception e) {
				e.printStackTrace();
			}finally {
				close(rs);
				close(pstmt);
			}
			return cart;
		}

		public int selectListCount() {
			int listCount = 0;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = "select count(*) from member";
			try {
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					listCount = rs.getInt(1);
				}
			}catch(Exception e) {
				e.printStackTrace();
			}finally {
				close(rs);
				close(pstmt);
			}
			return listCount;
		}

		public ArrayList<MemberBean> selectMemberList(int page, int limit) {
			ArrayList<MemberBean> memberList = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			
			int startrow = (page - 1) * limit + 1;
			int endrow = startrow + limit - 1;
			
			String sql = "select * from (select rownum rnum, a.* from (select * from member) a) where rnum between ? and ?";
			
			try {
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, startrow);
				pstmt.setInt(2, endrow);
				rs = pstmt.executeQuery();
				if(rs.next()) {
					memberList = new ArrayList<MemberBean>();
					do {
						MemberBean member = new MemberBean();
						member.setId(rs.getString("id"));
						member.setName(rs.getString("name"));
						member.setPass(rs.getString("pass"));
						member.setPhone_number(rs.getString("phone_number"));
						member.setEmail(rs.getString("email"));
						member.setBirthday(rs.getString("birthday"));
						memberList.add(member);
					}while(rs.next());
				}
			}catch(Exception e) {
				e.printStackTrace();
			}finally {
				close(rs);
				close(pstmt);
			}
			return memberList;
		}

		public int updateMember(MemberBean member) {
			int updateCount = 0;
			PreparedStatement pstmt = null;
			String sql = "update member set name=?, pass=?, phone_number=?, email=?, birthday=? where id=?";
			try {
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, member.getId());
				pstmt.setString(2, member.getName());
				pstmt.setString(3, member.getPass());
				pstmt.setString(4, member.getPhone_number());
				pstmt.setString(5, member.getEmail());
				pstmt.setString(6, member.getBirthday());
				updateCount = pstmt.executeUpdate();
			}catch(Exception e) {
				e.printStackTrace();
			}finally {
				close(pstmt);
			}
			return updateCount;
		}

		public int deleteMember(String id) {
			int deleteCount = 0;
			PreparedStatement pstmt = null;
			String sql = "delete from member where id = ?";
			try {
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, id);
				deleteCount = pstmt.executeUpdate();
			}catch(Exception e) {
				e.printStackTrace();
			}finally {
				close(pstmt);
			}
			return deleteCount;
		}

	

	}