package dao;

import static db.JdbcUtil.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import vo.MemberBean;

public class MemberDAO {
	Connection con;
	private static MemberDAO memberDAO;
	
	public static MemberDAO getInstance() {
		if(memberDAO == null)
			memberDAO = new MemberDAO();
		return memberDAO;
	}

	public void setConnection(Connection con) {
		this.con = con;
	}

	public int insertMember(MemberBean member) {
		int insertCount = 0;
		PreparedStatement pstmt = null;
		String sql = "insert into member values (?,?,?,?,?,?)";
		//(3)여기 보면 그냥 들어갈 부분에 물음표가 되어있잖아
		//(4)그래서 앞에 어떤 필드에 넣어줘라 라는 선언이 없기때문에 기존에 있는 필드 순으로 넣는거구나 인식하고
		//(5)밑에 선언되어있는 순서대로 값이 들어간거야
		//id, name, pass, phone_number, email, birthday
		//(1)기존에 테이블에 열이 이렇게 정의가 되어있잖아, 
		/*
		 * String sql =
		 * "INSERT INTO member(id,pass,name,phone_number,birthday,email) values(?,?,?,?,?,?)"
		 * ;
		 */
		//(6)그래서 이 쿼리를 보면 앞에 어떤 필드에 넣어라 라고 선언이 되어있잖아
		//(7)너가 아래에 선언했던 순서대로 쿼리에 필드를 선언한거라서 이쿼리로 하면 아마 값이 제대로 들어갈거야
		//INSERT INTO 테이블이름(필드이름1, 필드이름2, 필드이름3, ...) VALUES (데이터값1, 데이터값2, 데이터값3, ...)
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, member.getId());
			pstmt.setString(2, member.getName());
			pstmt.setString(3, member.getPass());
			pstmt.setString(4, member.getPhone_number());
			pstmt.setString(5, member.getEmail());
			pstmt.setString(6, member.getBirthday());
			//(2) 여기에 pstmt.setString(여기가 index값, 여기가 해당 index에 넣을 값)되어있는데
			
			insertCount = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		return insertCount;
	}

	public MemberBean selectMember(String id) {
		MemberBean member = null;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from member where id=?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				member = new MemberBean();
				member.setId(id);
				member.setName(rs.getString("name"));
				member.setPass(rs.getString("pass"));
				member.setPhone_number(rs.getString("phone_number"));
				member.setEmail(rs.getString("email"));
				member.setBirthday(rs.getString("birthday"));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			close(rs);
			close(pstmt);
		}
		return member;
	}

	public int selectListCount() {
		int listCount = 0;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select count(*) from member";
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				listCount = rs.getInt(1);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			close(rs);
			close(pstmt);
		}
		return listCount;
	}

	public ArrayList<MemberBean> selectMemberList(int page, int limit) {
		ArrayList<MemberBean> memberList = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		int startrow = (page - 1) * limit + 1;
		int endrow = startrow + limit - 1;
		
		String sql = "select * from (select rownum rnum, a.* from (select * from member) a) where rnum between ? and ?";
		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, startrow);
			pstmt.setInt(2, endrow);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				memberList = new ArrayList<MemberBean>();
				do {
					MemberBean member = new MemberBean();
					member.setId(rs.getString("id"));
					member.setName(rs.getString("name"));
					member.setPass(rs.getString("pass"));
					member.setPhone_number(rs.getString("phone_number"));
					member.setEmail(rs.getString("email"));
					member.setBirthday(rs.getString("birthday"));
					memberList.add(member);
				}while(rs.next());
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			close(rs);
			close(pstmt);
		}
		return memberList;
	}

	public int updateMember(MemberBean member) {
		int updateCount = 0;
		PreparedStatement pstmt = null;
		String sql = "update member set name=?, pass=?, phone_number=?, email=?, birthday=? where id=?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, member.getId());
			pstmt.setString(2, member.getName());
			pstmt.setString(3, member.getPass());
			pstmt.setString(4, member.getPhone_number());
			pstmt.setString(5, member.getEmail());
			pstmt.setString(6, member.getBirthday());
			updateCount = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		return updateCount;
	}

	public int deleteMember(String id) {
		int deleteCount = 0;
		PreparedStatement pstmt = null;
		String sql = "delete from member where id = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			deleteCount = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		return deleteCount;
	}

}
