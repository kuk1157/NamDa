package vo;

public class Specialties {
	private String product_code;
	private String title;
	private int price;
	private String content;
	private String image;
	private String status;
	



	public Specialties(String product_code, String title, int price, String content, String image, String status) {
		super();
		this.product_code = product_code;
		this.title = title;
		this.price = price;
		this.content = content;
		this.image = image;
		this.status = status;
	}


	public Specialties ( ) {
		
	}
	

	public String getProduct_code() {
		return product_code;
	}

	public void setProduct_code(String product_code) {
		this.product_code = product_code;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
}

