package vo;

public class Cart {

	private int index_num;
	private String id;
	private int qty;
	private String product_code;
	private int price;
	
	public Cart(int index_num, String id, int qty, String product_code, int price) {
		super();
		this.index_num = index_num;
		this.id = id;
		this.qty = qty;
		this.product_code = product_code;
		this.price = price;
	}
	public Cart() {
		// TODO Auto-generated constructor stub
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getIndex_num() {
		return index_num;
	}
	public void setIndex_num(int index_num) {
		this.index_num = index_num;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public String getProduct_code() {
		return product_code;
	}
	public void setProduct_code(String product_code) {
		this.product_code = product_code;
	}
	
}
